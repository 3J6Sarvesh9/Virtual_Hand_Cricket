***HOW TO RUN THE GAME?***

CLICK THE 'virtualhandcricket.bat' file